﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Email.Models
{
    public class Emails
    {
        public string fromEmail { get; set; }
        public string toEmail { get; set; }
        public string subject { get; set; }
        public string body { get; set; }
    }
}
