﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Email.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Email.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AmazonEmailController : ControllerBase
    {

        public AmazonEmailController()
        {
          
        }

        [HttpGet]
        public string Get()
        {
            
            return "server is running...";
        }
        [HttpPost]
        public bool Post(Emails email)
        {

            return Email.Helper.SendEmail.Send(email.toEmail, email.subject, email.body, email.fromEmail); 
        }
    }
}
