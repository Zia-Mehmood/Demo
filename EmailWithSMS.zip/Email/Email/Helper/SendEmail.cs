﻿using Amazon.SimpleEmail;
using Amazon.SimpleEmail.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Email.Helper
{
    public static class SendEmail
    {
        public static bool Send(String toEmail, String subject, String body, String fromEmail)
        {
            var awsConfig = new AmazonSimpleEmailServiceConfig()
            {
                //UseSecureStringForAwsSecretKey = true,
                ServiceURL = "your amazon url"
            };


            var awsClient = new AmazonSimpleEmailServiceClient("Your Key Id", "Your Access Key", awsConfig);

            var dest = new Destination();

            var mailObj = new SendEmailRequest();

            if (!String.IsNullOrEmpty(toEmail))
            {
                List<String> toEmails = toEmail.Split(',').Select(i => i).ToList();
                dest.ToAddresses = toEmails;
            }

            mailObj.Destination = dest;
           


            mailObj.Destination = dest;
            mailObj.ReturnPath = fromEmail;
            mailObj.Source = fromEmail;
            var emailbody = new Body
            {
                Html = new Content(body)
            };

            var title = new Content(subject);
            var message = new Message(title, emailbody);
            mailObj.Message = message;
            var ser = new SendEmailRequest();
            try
            {
                SendEmailResponse seResponse = awsClient.SendEmail(mailObj);
                if (seResponse.SendEmailResult.MessageId != string.Empty)
                {
                    return true;
                }
                return false;
            }
            catch (Exception e)
            {
                return false;
                //return e.Message.ToString();
            }
        }
    }
}
