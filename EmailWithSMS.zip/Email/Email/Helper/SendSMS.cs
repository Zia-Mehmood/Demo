﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Twilio;
using Twilio.Types;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Clients;
using Email.Models;

namespace Email.Helper
{
    public static class SendSMS
    {
       public static string Send(SMS sms)
        {
            try
            {
                const string accountSid = "ACXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
                const string authToken = "your_auth_token";
                TwilioClient.Init(accountSid, authToken);
                var message = MessageResource.Create(
                    body: sms.messageBody,
                    from: new Twilio.Types.PhoneNumber("+15017122661"),
                    to: new Twilio.Types.PhoneNumber(sms.toNumber)
                     );
                return "";
            }
            catch (Exception e)
            {

                return e.Message.ToString();
            }
        }
    }
}
