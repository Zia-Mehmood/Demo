﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Email.Models
{
    public class SMS
    {
        public string toNumber { get; set; }
        public string messageBody { get; set; }
    }
}
