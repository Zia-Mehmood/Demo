﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Exchange.WebServices.Auth.Validation;
using Twilio;
using Twilio.Types;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Clients;
using Email.Models;

namespace Email.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SMSController : ControllerBase
    {
        public string Get()
        {
            return "SMS Controller called.";
        }

        [HttpPost]
        public string Post(SMS sms)
        {
            return Email.Helper.SendSMS.Send(sms);
        }
    }
}